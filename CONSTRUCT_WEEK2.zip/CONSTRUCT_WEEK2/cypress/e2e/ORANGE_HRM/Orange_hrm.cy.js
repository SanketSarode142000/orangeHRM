import Login from "../../support/ORANGE_HRM/Login.cy";
import AdminGet from "../../support/ORANGE_HRM/AdminGet.cy";
import TextCheck from "../../support/ORANGE_HRM/TextCheck.cy";
import GeneralTest from "../../support/ORANGE_HRM/GeneralTest.cy";
import LogOut from "../../support/ORANGE_HRM/LogOut.cy";

describe('Orange hrm', () => {
    const LoginObj = new Login();
    const AdminGetObj = new AdminGet()
    const TextCheckObj = new TextCheck()
    const GeneralTestObj = new GeneralTest()
    const LogOutObj = new LogOut()


    it('Valid login', () => {
        LoginObj.ValidLogin()
    });  

    it('InValid login', () => {
        LoginObj.InvalidLogin()
    });

    it('ValidName', () => {
        LoginObj.ValidName()
    });

    it('InvalidName', () => {
        LoginObj.InvalidName()
    });





    it('admin get', () => {
        AdminGetObj.AdminGet()
    });

    it('PomGet', () => {
        AdminGetObj.PomGet()
    });
    
    it('LeaveGet', () => {
        AdminGetObj.LeaveGet()
    });

    it('TimeGet', () => {
        AdminGetObj.TimeGet()
    });





    it('TextCheckAdmin', () => {
        TextCheckObj.TextCheckAdmin()
    });

    it('TextCheckPOM', () => {
        TextCheckObj.TextCheckPOM()
    });

    it('TextCheckLeave', () => {
        TextCheckObj.TextCheckLeave()
    });

    it('TextCheckLeave', () => {
        TextCheckObj.TextCheckTime()
    });




    it('GeneralTestClick', () => {
        GeneralTestObj.GeneralTest()
    });

    it('clickOnFirstUsername', () => {
        GeneralTestObj.clickOnFirstUsername()
    });

    it('clickOnSecondUsername', () => {
        GeneralTestObj.clickOnSecondUsername()
    });

    it('clickOnThirdUsername', () => {
        GeneralTestObj.clickOnThirdUsername()
    });

    it('typeOnEmployeeNameInPIM', () => {
        GeneralTestObj.typeOnEmployeeNameInPIM()
    });

    it('typeOnEmployeeIDInPIM', () => {
        GeneralTestObj.typeOnEmployeeIDInPIM()
    });

    it('ClickOnSearchButtonInLeave', () => {
        GeneralTestObj.ClickOnSearchButtonInLeave()
    });

    it('ClickOnResetButtonInLeave', () => {
        GeneralTestObj.ClickOnResetButtonInLeave()
    });

    it('ClickOnViewButtonInTime', () => {
        GeneralTestObj.ClickOnViewButtonInTime()
    });
    
    it('ClickOnViewButtonAndClickOnFirstViewButtonInTime', () => {
        GeneralTestObj.ClickOnViewButtonAndClickOnFirstViewButtonInTime()
    });



    it('MyInfoChangeName', () => {
        GeneralTestObj.MyInfoChangeName()
    });

    it('MyInfoChangeMiddleName', () => {
        GeneralTestObj.MyInfoChangeMiddleName()
    });

    it('MyInfoChangeLastName', () => {
        GeneralTestObj.MyInfoChangeLastName()
    });

    it('MyInfoChangeEmployeeID', () => {
        GeneralTestObj.MyInfoChangeEmployeeID()
    });

    it('MyInfoChangeOtherID', () => {
        GeneralTestObj.MyInfoChangeOtherID()
    });

    it('MyInfoChangeDriversLicence', () => {
        GeneralTestObj.MyInfoChangeDriversLicence()
    });
 
    it('MyInfoChangeTestField', () => {
        GeneralTestObj.MyInfoChangeTestField()
    });


    
    it('MyInfoSaveTheChange1', () => {
        GeneralTestObj.MyInfoSaveTheChange1()
    });

    it('MyInfoSaveTheChange2', () => {
        GeneralTestObj.MyInfoSaveTheChange2()
    });


    it('BuzzGet', () => {
        GeneralTestObj.BuzzGet()
    });

    it('BuzzType_WhatIsInYourMind', () => {
        GeneralTestObj.BuzzType_WhatIsInYourMind()
    });

    it('BuzzType_WhatIsInYourMindSAVED', () => {
        GeneralTestObj.BuzzType_WhatIsInYourMindSAVED()
    });

    it('BuzzDoNotTypeAndTryToSAVE', () => {
        GeneralTestObj.BuzzDoNotTypeAndTryToSAVE()
    });

    it('BuzzClickOnMostLiked', () => {
        GeneralTestObj.BuzzClickOnMostLiked()
    });

    it('BuzzClickOnMostLikedAnyNowClickOnFirstPostComment', () => {
        GeneralTestObj.BuzzClickOnMostLikedAnyNowClickOnFirstPostComment()
    });

    it('BuzzClickOnMostLikedAnyNowClickOnFirstPostCommentAndComment', () => {
        GeneralTestObj.BuzzClickOnMostLikedAnyNowClickOnFirstPostCommentAndComment()
    });

    it('BuzzClickOnMostLikedAnyNowClickOnFirstPostCommentAndCommentAndSAVE', () => {
        GeneralTestObj.BuzzClickOnMostLikedAnyNowClickOnFirstPostCommentAndCommentAndSAVE()
    });

    it('BuzzClickOnMostLikedAnyNowClickOnFirstPostCommentAndCommentAndSAVE', () => {
        GeneralTestObj.BuzzClickOnMostLikedAnyNowClickOnFirstPostCommentAndCommentAndSAVE()
    });






    it('urlCheck', () => {
        GeneralTestObj.urlCheck()
    });

    it('titleCheck', () => {
        GeneralTestObj.titleCheck()
    });

    it('titleCheckNegative', () => {
        GeneralTestObj.titleCheckNegative()
    });

    it('PIMid_format', () => {
        GeneralTestObj.PIMid_format()
    });

    it('PIM_EmployeeSearch', () => {
        GeneralTestObj.PIM_EmployeeSearch()
    });

    it('SEARCH_buttonWork', () => {
        GeneralTestObj.SEARCH_buttonWork()
    });

    it('SEARCH_buttonWork_111', () => {
        GeneralTestObj.SEARCH_buttonWork_111()
    });

    it('LeaveRequiredMark', () => {
        GeneralTestObj.LeaveRequiredMark()
    });

    it('My_InfoRequiredMark', () => {
        GeneralTestObj.My_InfoRequiredMark()
    });

    it('AdminInvalidName', () => {
        GeneralTestObj.AdminInvalidName()
    });

    it('AdminQualificationCheck', () => {
        GeneralTestObj.AdminQualificationCheck()
    });

    it('AdminNationalityCheck', () => {
        GeneralTestObj.AdminNationalityCheck()
    });

    it('Admin__UserName', () => {
        GeneralTestObj.Admin__UserName()
    });

    it('Admin__ChangeUserNameToInvalid', () => {
        GeneralTestObj.Admin__ChangeUserNameToInvalid()
    });
    



    it('LogOut2', () => {
        LogOutObj.LogOut2()
    });

    

    
    


    
    

    

    

    
    
    

    





    
});

