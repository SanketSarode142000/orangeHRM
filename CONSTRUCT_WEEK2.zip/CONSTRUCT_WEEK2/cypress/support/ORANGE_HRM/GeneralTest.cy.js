class GeneralTest{
    GeneralTest(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[1]').click()
        cy.xpath('(//span[@class="oxd-checkbox-input oxd-checkbox-input--active --label-right oxd-checkbox-input"])[1]').click()
    }

    clickOnFirstUsername(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[1]').click()
        cy.xpath('(//span[@class="oxd-checkbox-input oxd-checkbox-input--active --label-right oxd-checkbox-input"])[2]').click()
    }

    clickOnSecondUsername(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[1]').click()
        cy.xpath('(//span[@class="oxd-checkbox-input oxd-checkbox-input--active --label-right oxd-checkbox-input"])[3]').click()
    }

    clickOnThirdUsername(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[1]').click()
        cy.xpath('(//span[@class="oxd-checkbox-input oxd-checkbox-input--active --label-right oxd-checkbox-input"])[4]').click()
    }

    typeOnEmployeeNameInPIM(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[2]').click()
        cy.xpath('(//input[@placeholder="Type for hints..."])[1]').type("Sanket")
    }

    typeOnEmployeeIDInPIM(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[2]').click()
        cy.xpath('(//input[@placeholder="Type for hints..."])[2]').type("ft38_566")
    }

    ClickOnSearchButtonInLeave(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[3]').click()
        cy.xpath('//button[@class="oxd-button oxd-button--medium oxd-button--secondary orangehrm-left-space"]').click()
    }

    ClickOnResetButtonInLeave(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[3]').click()
        cy.xpath('//button[@class="oxd-button oxd-button--medium oxd-button--ghost"]').click()
    }

    ClickOnViewButtonInTime(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[4]').click()
        cy.xpath('//button[@class="oxd-button oxd-button--medium oxd-button--secondary orangehrm-left-space"]').click();
    }

    ClickOnViewButtonAndClickOnFirstViewButtonInTime(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[4]').click()
        cy.xpath('(//button[@class="oxd-button oxd-button--medium oxd-button--text oxd-table-cell-action-space"])[1]').click();
    }

    MyInfoChangeName(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[6]').click()
        cy.xpath('//input[@class="oxd-input oxd-input--active orangehrm-firstname"]').clear().type("Sanket")
    }

    MyInfoChangeMiddleName(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[6]').click()
        cy.xpath('//input[@class="oxd-input oxd-input--active orangehrm-middlename"]').clear().type("Bharatrao")
    }

    MyInfoChangeLastName(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[6]').click()
        cy.xpath('//input[@class="oxd-input oxd-input--active orangehrm-lastname"]').clear().type("Sarode")
    }

    MyInfoChangeEmployeeID(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[6]').click()
        cy.xpath('(//input[@class="oxd-input oxd-input--active"])[2]').clear().type("ft38_566")
    }

    MyInfoChangeOtherID(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[6]').click()
        cy.xpath('(//input[@class="oxd-input oxd-input--active"])[3]').clear().type("56688888")
    }

    MyInfoChangeDriversLicence(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[6]').click()
        cy.xpath('(//input[@class="oxd-input oxd-input--active"])[4]').clear().type("788805")
    }

    MyInfoChangeTestField(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[6]').click()
        cy.xpath('(//input[@class="oxd-input oxd-input--active"])[7]').clear().type("001")
    }


    // FAILED TEST CASES 2
    MyInfoSaveTheChange1(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[6]').click()
        cy.xpath('(//input[@class="oxd-input oxd-input--active"])[2]').clear().type("ft38_566")
        cy.xpath('(//input[@class="oxd-input oxd-input--active"])[3]').clear().type("ft38_566")
        cy.xpath('(//input[@class="oxd-input oxd-input--active"])[4]').clear().type("ft38_566")
        cy.xpath('(//button[@type="submit"])[1]').click()
    }


    MyInfoSaveTheChange2(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[6]').click()
        cy.xpath('(//input[@class="oxd-input oxd-input--active"])[7]').clear().type("001")
        cy.xpath('(//button[@class="oxd-button oxd-button--medium oxd-button--secondary orangehrm-left-space"])[2]').click()
    }

    BuzzGet(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[11]').click()
    }

    BuzzType_WhatIsInYourMind(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[11]').click()
        cy.xpath('(//textarea[@class="oxd-buzz-post-input"])').type("Hello every one!!!")
    }

    BuzzType_WhatIsInYourMindSAVED(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[11]').click()
        cy.xpath('(//div[@class="oxd-buzz-post oxd-buzz-post--active"])').type("Hello every one!!!")
        cy.xpath('(//button[@class="oxd-button oxd-button--medium oxd-button--main"])').click()
    }

// // No pop up is showing here FAILED
    BuzzDoNotTypeAndTryToSAVE(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[11]').click()
        cy.xpath('(//button[@class="oxd-button oxd-button--medium oxd-button--main"])').click()
    }

    BuzzClickOnMostLiked(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[11]').click()
        cy.xpath('(//button[@class="oxd-button oxd-button--medium oxd-button--label-warn orangehrm-post-filters-button"])').click()
    }

    BuzzClickOnMostLikedAnyNowClickOnFirstPostComment(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[11]').click()
        cy.xpath('(//button[@class="oxd-button oxd-button--medium oxd-button--label-warn orangehrm-post-filters-button"])').click()
        cy.xpath('(//i[@class="oxd-icon bi-chat-text-fill"])[1]').click()
    }

    BuzzClickOnMostLikedAnyNowClickOnFirstPostCommentAndComment(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[11]').click()
        cy.xpath('(//button[@class="oxd-button oxd-button--medium oxd-button--label-warn orangehrm-post-filters-button"])').click()
        cy.xpath('(//i[@class="oxd-icon bi-chat-text-fill"])[2]').click()
        cy.xpath('(//i[@class="oxd-icon bi-chat-text-fill"])[1]').type("VERY NICE!!!")
    }

    BuzzClickOnMostLikedAnyNowClickOnFirstPostCommentAndCommentAndSAVE(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[11]').click()
        cy.xpath('(//button[@class="oxd-button oxd-button--medium oxd-button--label-warn orangehrm-post-filters-button"])').click()
        cy.xpath('(//i[@class="oxd-icon bi-chat-text-fill"])[2]').click()
        cy.xpath('(//i[@class="oxd-icon bi-chat-text-fill"])[1]').type("VERY NICE!!!").click()
    }

    urlCheck(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.url().should('includes', 'index')
    }

    titleCheck(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.title().should('includes', 'OrangeHRM')
    }

     // fail test case - negative tyest case
    titleCheckNegative(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.title().should('includes', 'BlackHRM')
    }


    // NEGATIVE FAILED
    PIMid_format(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[2]').click()
        cy.xpath('(//div[@class="oxd-table-cell oxd-padding-cell"])[2]').should('contains.text','03')
        cy.xpath('(//div[@class="oxd-table-cell oxd-padding-cell"])[11]').should('contains.text','0')      
    }


    // FAILED
    PIM_EmployeeSearch(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[2]').click()
        cy.xpath('(//input[@placeholder="Type for hints..."])[1]').type('amelia')
        cy.xpath('(//input[@class="oxd-input oxd-input--active"])[2]').type('0')
        cy.xpath('//button[@class="oxd-button oxd-button--medium oxd-button--secondary orangehrm-left-space"]').click()
        cy.xpath('(//span[@class="oxd-text oxd-text--span"])[1]').should('have.text','Record Found')
    }

    SEARCH_buttonWork(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//input[@class="oxd-input oxd-input--active"])[1]').type('adminnn').click()
    }

    SEARCH_buttonWork_111(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//input[@class="oxd-input oxd-input--active"])[1]').type('111').click()
    }

    LeaveRequiredMark(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[3]').click()
        cy.xpath('(//label[@class="oxd-label"])[1]').should('have.text','*')
    }

    My_InfoRequiredMark(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[6]').click()
        cy.xpath('(//button[@class="oxd-button oxd-button--medium oxd-button--secondary orangehrm-left-space"])[1]').should('Save','not.exist')
    }

    AdminInvalidName(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[1]').click()
        cy.xpath('(//div[@class="oxd-table-cell oxd-padding-cell"])[20]').should('have.text','Jobinsam')
    }

    AdminQualificationCheck(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[1]').click()
        cy.xpath('(//li[@class="oxd-topbar-body-nav-tab --parent"])[3]').click()
        cy.xpath('(//a[@class="oxd-topbar-body-nav-tab-link"])[1]').click()
        cy.xpath('(//div[@class="oxd-table-cell oxd-padding-cell"])[6]').should('eq','name')
    }

    AdminNationalityCheck(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[1]').click()
        cy.xpath('(//li[@class="oxd-topbar-body-nav-tab"])[1]').click()
        cy.get('.oxd-button').should('include.text','Choose your country');
    }

    Admin__UserName(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[1]').click()
        cy.xpath('(//p[@class="oxd-userdropdown-name"])').should('have.text','Admin')
    }

    Admin__ChangeUserNameToInvalid(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[1]').click()
        cy.xpath('(//i[@class="oxd-icon bi-pencil-fill"])[2]').click()
        cy.xpath('(//input[@class="oxd-input oxd-input--active"])[2]').clear().type('Sanket')
        cy.xpath('//button[@class="oxd-button oxd-button--medium oxd-button--secondary orangehrm-left-space"]').click()
        cy.go('back')
        cy.xpath('(//div[@class="oxd-table-cell oxd-padding-cell"])[8]').should('have.text','Sanket')
    }   
}

export default GeneralTest