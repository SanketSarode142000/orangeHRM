class Login{
    ValidLogin(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
    }

    // invalid login
    InvalidLogin(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin111')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123111")
        cy.xpath('//button[@type="submit"]').click()       
    }

    ValidName(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
    }

    InvalidName(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin111')
    }
}

export default Login
