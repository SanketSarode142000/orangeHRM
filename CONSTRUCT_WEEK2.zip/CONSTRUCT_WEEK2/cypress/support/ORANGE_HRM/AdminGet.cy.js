class AdminGet{
    AdminGet(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[1]').click()
    }


    PomGet(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[2]').click()
    }

    LeaveGet(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[3]').click()
    }


    TimeGet(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[4]').click()
    }


}

export default AdminGet
