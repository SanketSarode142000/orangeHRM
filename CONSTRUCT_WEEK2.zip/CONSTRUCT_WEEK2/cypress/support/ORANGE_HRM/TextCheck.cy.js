class TextCheck{
    TextCheckAdmin(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[1]').should('have.text','Admin')
    }

    TextCheckPOM(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[2]').should('have.text','PIM')
    }

    TextCheckLeave(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[3]').should('have.text','Leave')
    }

    TextCheckTime(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        cy.xpath('(//input[@placeholder="Username"])').type('Admin')
        cy.xpath('(//input[@placeholder="Password"])').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[4]').should('have.text','Time')
    }
}

export default TextCheck